#!/usr/bin/env node
/**
 * Verifies a platform setup:  npm run probe -- blinkit
 * Prints HTTP health, how many products were parsed and sample prices so you
 * can confirm the request, location and price units are right.
 */

require('dotenv').config();
require('dotenv').config({ path: require('path').join(__dirname, '..', '..', 'platforms.local.env') });

const { loadPlatformConfig, fetchPlatformDeals, getPlatformStats } = require('./engine');
const { validateItems } = require('../validator');
const { diagnose } = require('../health');

async function main() {
  const key = (process.argv[2] || '').toLowerCase();
  const { platforms } = loadPlatformConfig();
  const cfg = platforms[key];

  if (!cfg) {
    console.error(`Usage: npm run probe -- <${Object.keys(platforms).join('|')}>`);
    process.exit(1);
  }

  if (!cfg.requests || cfg.requests.length === 0) {
    console.error(`${key} has no requests yet. Run: npm run platform:import -- ${key} "<curl>" --name <label>`);
    process.exit(1);
  }

  console.log(`Probing ${cfg.name} (${cfg.requests.length} request(s))...\n`);

  const items = await fetchPlatformDeals(key, { ...cfg, requests: cfg.requests.map((r) => ({ ...r, pages: 1 })) });
  const stats = getPlatformStats(key);
  console.log('\nHTTP stats:', JSON.stringify(stats));

  const problem = diagnose({ itemCount: items.length, stats });
  if (problem) {
    console.log(`\n❌ ${problem.code}: ${problem.text}`);
    if (problem.code === 'AUTH') {
      console.log('   → Re-import a fresh cURL (cookies expire) or set a residential proxy: ' + `${key.toUpperCase()}_PROXY`);
    }
    process.exit(2);
  }

  const valid = validateItems(items, key);
  console.log(`\n✅ Parsed ${items.length} products (${valid.length} valid).`);

  const sorted = [...valid].sort((a, b) => b.discount - a.discount).slice(0, 5);
  console.log('\nTop discounts:');
  for (const it of sorted) {
    console.log(`  ₹${it.price} (MRP ₹${it.mrp}, ${it.discount}% off) - ${it.name} ${it.pack ? '[' + it.pack + ']' : ''}`);
  }

  // price-unit sanity check
  const prices = valid.map((i) => i.price).filter((p) => p > 0);
  if (prices.length >= 5) {
    const allWhole100 = prices.every((p) => p % 100 === 0);
    const median = [...prices].sort((a, b) => a - b)[Math.floor(prices.length / 2)];
    if (allWhole100 || median > 2000) {
      console.log('\n⚠️  Prices look like PAISE (very large / all multiples of 100). Set "priceDivisor": 100 for this platform in platforms.config.json.');
    }
  }
}

main().catch((e) => {
  console.error('Probe failed:', e.message);
  process.exit(1);
});
