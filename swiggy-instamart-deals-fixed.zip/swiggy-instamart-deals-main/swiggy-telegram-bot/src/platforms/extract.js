/**
 * Generic product extractor.
 *
 * Quick-commerce APIs (Blinkit, Zepto, Flipkart Minutes...) nest products deep
 * inside UI "widget" JSON whose layout changes often. Instead of hardcoding one
 * path, we walk the whole response and treat any object that has a NAME, a
 * selling PRICE and an MRP as a product. Field names are matched from lists of
 * the names these platforms are known to use.
 */

const NAME_KEYS = ['name', 'display_name', 'displayName', 'product_name', 'productName', 'item_name', 'title'];
const PRICE_KEYS = [
  'price', 'offer_price', 'offerPrice', 'selling_price', 'sellingPrice',
  'discounted_price', 'discountedPrice', 'discountedSellingPrice', 'final_price',
  'finalPrice', 'sale_price', 'salePrice', 'special_price', 'sp'
];
const MRP_KEYS = [
  'mrp', 'max_retail_price', 'maxRetailPrice', 'normal_price', 'original_price',
  'originalPrice', 'marked_price', 'markedPrice', 'list_price', 'listPrice', 'strike_price'
];
const ID_KEYS = [
  'product_id', 'productId', 'sku_id', 'skuId', 'variant_id', 'variantId',
  'item_id', 'itemId', 'listing_id', 'listingId', 'id'
];
const PACK_KEYS = [
  'unit', 'quantity', 'pack_size', 'packSize', 'weight', 'variant_name',
  'variantName', 'quantity_description', 'size'
];
const BRAND_KEYS = ['brand', 'brand_name', 'brandName'];
const IMAGE_KEYS = ['image_url', 'imageUrl', 'image', 'img', 'thumbnail', 'images'];

const MAX_DEPTH = 30;

function toNumber(value) {
  if (typeof value === 'number') return Number.isFinite(value) ? value : NaN;

  if (typeof value === 'string') {
    const cleaned = value.replace(/[₹,\s]|rs\.?|inr/gi, '');
    if (!/^-?\d+(\.\d+)?$/.test(cleaned)) return NaN;
    return Number(cleaned);
  }

  if (value && typeof value === 'object') {
    for (const k of ['value', 'units', 'amount', 'text', 'display', 'price']) {
      if (k in value) {
        const n = toNumber(value[k]);
        if (Number.isFinite(n)) return n;
      }
    }
  }

  return NaN;
}

function toText(value) {
  if (typeof value === 'string') return value.trim();
  if (typeof value === 'number') return String(value);
  if (value && typeof value === 'object' && typeof value.text === 'string') return value.text.trim();
  return '';
}

function firstNumber(obj, keys) {
  for (const key of keys) {
    if (key in obj) {
      const n = toNumber(obj[key]);
      if (Number.isFinite(n)) return n;
    }
  }
  return NaN;
}

function firstText(obj, keys) {
  for (const key of keys) {
    if (key in obj) {
      const t = toText(obj[key]);
      if (t) return t;
    }
  }
  return '';
}

function readImage(obj) {
  for (const key of IMAGE_KEYS) {
    const v = obj[key];
    if (typeof v === 'string' && /^https?:\/\//i.test(v)) return v;
    if (Array.isArray(v) && v.length) {
      const first = v[0];
      if (typeof first === 'string' && /^https?:\/\//i.test(first)) return first;
      if (first && typeof first.url === 'string' && /^https?:\/\//i.test(first.url)) return first.url;
    }
    if (v && typeof v === 'object' && typeof v.url === 'string' && /^https?:\/\//i.test(v.url)) return v.url;
  }
  return null;
}

function readStock(obj) {
  for (const k of ['in_stock', 'inStock', 'is_available', 'isAvailable', 'available']) {
    if (typeof obj[k] === 'boolean') return obj[k];
  }
  for (const k of ['out_of_stock', 'outOfStock', 'is_sold_out', 'isSoldOut', 'sold_out', 'unavailable', 'isUnavailable']) {
    if (typeof obj[k] === 'boolean') return !obj[k];
  }
  if (typeof obj.inventory === 'number') return obj.inventory > 0;
  if (obj.inventory && typeof obj.inventory === 'object') {
    if (typeof obj.inventory.inStock === 'boolean') return obj.inventory.inStock;
    if (typeof obj.inventory.in_stock === 'boolean') return obj.inventory.in_stock;
  }
  return true;
}

function round2(n) {
  return Math.round(n * 100) / 100;
}

/**
 * @param {*} json              parsed API response
 * @param {object} opts
 * @param {number} opts.priceDivisor   e.g. 100 when the API returns paise
 * @param {string} opts.platform
 * @param {string} opts.category
 * @param {string} opts.urlTemplate    e.g. https://blinkit.com/s/?q={query}
 */
function extractProducts(json, opts = {}) {
  const divisor = Number(opts.priceDivisor) > 0 ? Number(opts.priceDivisor) : 1;
  const found = new Map();
  const seen = new WeakSet();

  function consider(obj) {
    const name = firstText(obj, NAME_KEYS);
    if (!name || name.length < 2 || name.length > 200) return;

    const rawPrice = firstNumber(obj, PRICE_KEYS);
    const rawMrp = firstNumber(obj, MRP_KEYS);
    if (!Number.isFinite(rawPrice) || !Number.isFinite(rawMrp)) return;
    if (rawMrp <= 0 || rawPrice < 0) return;

    const price = round2(rawPrice / divisor);
    const mrp = round2(rawMrp / divisor);
    const pack = firstText(obj, PACK_KEYS);
    const id = firstText(obj, ID_KEYS) || name;
    const discount = mrp > 0 ? Math.round(((mrp - price) / mrp) * 100) : 0;
    const brandValue = firstText(obj, BRAND_KEYS);

    const searchLink = opts.urlTemplate
      ? String(opts.urlTemplate).replace('{query}', encodeURIComponent(name))
      : null;

    const item = {
      skuId: id,
      name,
      parentProductId: null,
      brand: brandValue || '',
      pack,
      price,
      mrp,
      discount,
      category: opts.category || '',
      subCategory: '',
      rating: null,
      ratingCount: null,
      imageUrl: readImage(obj),
      itemLink: searchLink,
      searchLink,
      platform: opts.platform || '',
      dealType: opts.platform || 'platform',
      inStock: readStock(obj)
    };

    const key = `${id}|${pack}`;
    const existing = found.get(key);
    if (!existing || item.price < existing.price) found.set(key, item);
  }

  function walk(node, depth) {
    if (!node || typeof node !== 'object' || depth > MAX_DEPTH) return;
    if (seen.has(node)) return;
    seen.add(node);

    if (Array.isArray(node)) {
      for (const child of node) walk(child, depth + 1);
      return;
    }

    consider(node);

    for (const child of Object.values(node)) {
      if (child && typeof child === 'object') walk(child, depth + 1);
    }
  }

  walk(json, 0);

  return [...found.values()].filter((item) => item.inStock !== false);
}

module.exports = { extractProducts, toNumber };
