/**
 * Config-driven connector for quick-commerce platforms.
 *
 * Each platform in platforms.config.json has a list of `requests` (captured
 * from the real website with curlImport.js). The engine replays them for the
 * configured location, pages through results, extracts products with the
 * generic extractor and tags them with the platform.
 */

const fs = require('fs');
const path = require('path');
const { extractProducts } = require('./extract');

const CONFIG_PATH = path.join(__dirname, '..', '..', 'platforms.config.json');

const SENSITIVE_HEADER_RE =
  /^(cookie|authorization|auth[_-]?key|x-auth.*|.*token.*|.*session.*|x-csrf.*|x-api-key|.*secret.*)$/i;

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

const statsByPlatform = {};

function loadPlatformConfig() {
  const raw = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
  const defaults = raw.defaults || {};
  const platforms = {};

  for (const [key, cfg] of Object.entries(raw.platforms || {})) {
    platforms[key] = { key, ...defaults, ...cfg };
  }

  return { defaults, platforms, raw };
}

function listPlatformKeys() {
  try {
    return Object.keys(loadPlatformConfig().platforms);
  } catch {
    return [];
  }
}

function getPlatformStats(key) {
  return statsByPlatform[key] || null;
}

function envKey(platformKey) {
  return platformKey.toUpperCase();
}

function parseJsonEnv(name) {
  const value = process.env[name];
  if (!value) return {};
  try {
    const parsed = JSON.parse(value);
    return parsed && typeof parsed === 'object' ? parsed : {};
  } catch {
    console.warn(`[Platforms] ${name} is not valid JSON; ignoring it.`);
    return {};
  }
}

function substitute(text, vars) {
  if (typeof text !== 'string') return text;
  return text.replace(/\{(\w+)\}/g, (match, name) =>
    vars[name] !== undefined && vars[name] !== null && vars[name] !== '' ? String(vars[name]) : match
  );
}

function buildHeaders(cfg, req, vars) {
  const key = envKey(cfg.key);
  const merged = {};

  for (const source of [cfg.headers || {}, req.headers || {}, parseJsonEnv(`${key}_EXTRA_HEADERS`)]) {
    for (const [name, value] of Object.entries(source)) {
      merged[String(name).toLowerCase()] = substitute(String(value), vars);
    }
  }

  if (process.env[`${key}_COOKIE`]) merged.cookie = process.env[`${key}_COOKIE`];

  return merged;
}

function applyPage(req, page, url, body) {
  if (!req.pageParam) return { url, body };

  const value = (Number(req.pageStart) || 0) + page * (Number(req.pageStep) || 1);

  if (req.pageIn === 'body') {
    try {
      const obj = JSON.parse(body || '{}');
      obj[req.pageParam] = value;
      return { url, body: JSON.stringify(obj) };
    } catch {
      return { url, body };
    }
  }

  const parsed = new URL(url);
  parsed.searchParams.set(req.pageParam, String(value));
  return { url: parsed.toString(), body };
}

async function doFetch(url, init, proxy) {
  if (proxy) {
    // Residential proxy support (needed when the site blocks datacenter IPs).
    const { ProxyAgent, fetch: proxyFetch } = require('undici');
    return proxyFetch(url, { ...init, dispatcher: new ProxyAgent(proxy) });
  }
  return fetch(url, init);
}

async function sendRequest(cfg, req, page, stats) {
  const key = envKey(cfg.key);
  const vars = {
    lat: process.env[`${key}_LAT`] || cfg.location?.lat,
    lon: process.env[`${key}_LON`] || cfg.location?.lon,
    pincode: process.env[`${key}_PINCODE`] || cfg.location?.pincode,
    storeId: process.env[`${key}_STORE_ID`] || cfg.location?.storeId
  };

  let url = substitute(req.url, vars);
  let body = req.body !== undefined && req.body !== null ? substitute(String(req.body), vars) : undefined;
  ({ url, body } = applyPage(req, page, url, body));

  const method = String(req.method || (body ? 'POST' : 'GET')).toUpperCase();
  const headers = buildHeaders(cfg, req, vars);
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), Number(cfg.timeoutMs) || 20000);

  stats.total++;

  try {
    const res = await doFetch(
      url,
      { method, headers, body: method === 'GET' || method === 'HEAD' ? undefined : body, signal: controller.signal },
      process.env[`${key}_PROXY`]
    );

    const text = await res.text();

    if (!res.ok) {
      stats[res.status] = (stats[res.status] || 0) + 1;
      return { ok: false, status: res.status };
    }

    const looksLikeHtml =
      /text\/html/i.test(res.headers?.get?.('content-type') || '') || /^\s*</.test(text);

    if (looksLikeHtml) {
      // 200 + HTML instead of JSON = bot-protection challenge page.
      stats[403] = (stats[403] || 0) + 1;
      return { ok: false, status: 403, challenge: true };
    }

    try {
      const json = JSON.parse(text);
      stats.ok++;
      return { ok: true, status: res.status, json };
    } catch {
      stats[0] = (stats[0] || 0) + 1;
      return { ok: false, status: 0, invalid: true };
    }
  } catch (error) {
    stats[0] = (stats[0] || 0) + 1;
    return { ok: false, status: 0, error: String(error.message || error) };
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Scans every configured request of one platform.
 * Returns normalized items (same shape the Swiggy scraper produces).
 */
async function fetchPlatformDeals(platformKey, overrideConfig = null) {
  const cfg = overrideConfig || loadPlatformConfig().platforms[platformKey];
  if (!cfg) throw new Error(`Unknown platform "${platformKey}".`);

  const stats = { total: 0, ok: 0 };
  statsByPlatform[platformKey] = stats;

  const requests = Array.isArray(cfg.requests) ? cfg.requests : [];
  const delayMs = Number(cfg.delayMs) >= 0 ? Number(cfg.delayMs) : 1200;
  const merged = new Map();

  for (const req of requests) {
    const pages = Math.max(1, Number(req.pages ?? cfg.pages) || 1);

    for (let page = 0; page < pages; page++) {
      const result = await sendRequest(cfg, req, page, stats);

      if (!result.ok) {
        console.warn(
          `[${platformKey}] "${req.name || req.url}" page ${page + 1} failed (` +
          `${result.challenge ? 'bot challenge' : result.status || result.error || 'network'}).`
        );
        break;
      }

      const items = extractProducts(result.json, {
        priceDivisor: cfg.priceDivisor,
        platform: platformKey,
        category: req.name || cfg.name || platformKey,
        urlTemplate: cfg.urlTemplate
      });

      let added = 0;
      for (const item of items) {
        const k = `${item.skuId}|${item.pack}`;
        const existing = merged.get(k);
        if (!existing) added++;
        if (!existing || item.price < existing.price) merged.set(k, item);
      }

      // stop paging as soon as a page adds nothing new
      if (added === 0) break;

      if (page < pages - 1) await sleep(delayMs);
    }

    await sleep(delayMs);
  }

  console.log(
    `[${platformKey}] ${requests.length} requests, ${stats.total} HTTP calls, ${merged.size} unique products.`
  );

  return [...merged.values()];
}

module.exports = {
  CONFIG_PATH,
  SENSITIVE_HEADER_RE,
  loadPlatformConfig,
  listPlatformKeys,
  getPlatformStats,
  fetchPlatformDeals,
  extractProducts
};
