#!/usr/bin/env node
/**
 * Imports a request copied from your browser into platforms.config.json.
 *
 * Usage (Chrome/Edge: DevTools -> Network -> right-click the product-list
 * request -> Copy -> Copy as cURL):
 *
 *   npm run platform:import -- blinkit "<paste curl>" --name Dairy \
 *        [--pages 3] [--page-param offset] [--page-step 15] [--page-in query|body]
 *   npm run platform:import -- zepto --file curl.txt --name Fresh
 *
 * Secrets (cookie, auth tokens, session ids) are NOT written to the config
 * (it is committed to git). They go to platforms.local.env, which is git-ignored.
 */

const fs = require('fs');
const path = require('path');
const { CONFIG_PATH, SENSITIVE_HEADER_RE } = require('./engine');

const ENV_FILE = path.join(__dirname, '..', '..', 'platforms.local.env');
const DROP_HEADERS = new Set(['host', 'content-length', 'accept-encoding', 'connection']);

function tokenize(command) {
  const input = String(command).replace(/\\\r?\n/g, ' ');
  const tokens = [];
  let i = 0;

  while (i < input.length) {
    while (i < input.length && /\s/.test(input[i])) i++;
    if (i >= input.length) break;

    let token = '';
    let started = false;

    while (i < input.length && !/\s/.test(input[i])) {
      const ch = input[i];
      started = true;

      if (ch === "'") {
        i++;
        while (i < input.length && input[i] !== "'") token += input[i++];
        i++;
      } else if (ch === '$' && input[i + 1] === "'") {
        i += 2;
        while (i < input.length && input[i] !== "'") {
          if (input[i] === '\\') {
            const n = input[i + 1];
            if (n === 'n') { token += '\n'; i += 2; }
            else if (n === 't') { token += '\t'; i += 2; }
            else if (n === 'r') { token += '\r'; i += 2; }
            else if (n === 'x') { token += String.fromCharCode(parseInt(input.slice(i + 2, i + 4), 16)); i += 4; }
            else if (n === 'u') { token += String.fromCharCode(parseInt(input.slice(i + 2, i + 6), 16)); i += 6; }
            else { token += n; i += 2; }
          } else {
            token += input[i++];
          }
        }
        i++;
      } else if (ch === '"') {
        i++;
        while (i < input.length && input[i] !== '"') {
          if (input[i] === '\\' && '"\\$`'.includes(input[i + 1])) { token += input[i + 1]; i += 2; }
          else token += input[i++];
        }
        i++;
      } else if (ch === '\\') {
        token += input[i + 1] || '';
        i += 2;
      } else {
        token += ch;
        i++;
      }
    }

    if (started) tokens.push(token);
  }

  return tokens;
}

function parseCurl(command) {
  const tokens = tokenize(command);
  const result = { method: '', url: '', headers: {}, body: undefined };

  for (let i = 0; i < tokens.length; i++) {
    const t = tokens[i];

    if (i === 0 && t.toLowerCase() === 'curl') continue;

    if (t === '-H' || t === '--header') {
      const h = tokens[++i] || '';
      const idx = h.indexOf(':');
      if (idx > 0) result.headers[h.slice(0, idx).trim().toLowerCase()] = h.slice(idx + 1).trim();
    } else if (t === '-X' || t === '--request') {
      result.method = (tokens[++i] || '').toUpperCase();
    } else if (/^(-d|--data|--data-raw|--data-binary|--data-ascii|--data-urlencode)$/.test(t)) {
      result.body = tokens[++i];
    } else if (t === '-b' || t === '--cookie') {
      result.headers.cookie = tokens[++i];
    } else if (t === '-A' || t === '--user-agent') {
      result.headers['user-agent'] = tokens[++i];
    } else if (t === '-e' || t === '--referer') {
      result.headers.referer = tokens[++i];
    } else if (t === '--url') {
      result.url = tokens[++i];
    } else if (t.startsWith('-')) {
      // ignored flags: --compressed, -L, -s, -k, -i, -v ...
    } else if (!result.url) {
      result.url = t;
    }
  }

  if (!result.method) result.method = result.body !== undefined ? 'POST' : 'GET';
  return result;
}

function parseArgs(argv) {
  const out = { _: [] };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a.startsWith('--') && ['name', 'pages', 'page-param', 'page-step', 'page-in', 'page-start', 'file'].includes(a.slice(2))) {
      out[a.slice(2)] = argv[++i];
    } else {
      out._.push(a);
    }
  }
  return out;
}

function readEnvFile() {
  try {
    return fs.readFileSync(ENV_FILE, 'utf8').split(/\r?\n/);
  } catch {
    return [];
  }
}

const LOCATION_NAMES = {
  lat: 'lat', latitude: 'lat',
  lon: 'lon', lng: 'lon', long: 'lon', longitude: 'lon',
  pincode: 'pincode', pin: 'pincode', pin_code: 'pincode', postalcode: 'pincode',
  storeid: 'storeId', store_id: 'storeId'
};

function locationVar(name) {
  return LOCATION_NAMES[String(name).toLowerCase().replace(/[-\s]/g, '')] || null;
}

function replaceInJson(node, found) {
  if (Array.isArray(node)) return node.map((n) => replaceInJson(n, found));
  if (node && typeof node === 'object') {
    const out = {};
    for (const [k, v] of Object.entries(node)) {
      const variable = locationVar(k);
      if (variable && (typeof v === 'string' || typeof v === 'number')) {
        found[variable] = String(v);
        out[k] = `{${variable}}`;
      } else {
        out[k] = replaceInJson(v, found);
      }
    }
    return out;
  }
  return node;
}

function saveEnvVars(vars) {
  const entries = Object.entries(vars);
  if (entries.length === 0) return;

  const lines = readEnvFile().filter((l) => l.trim());
  for (const [name, value] of entries) {
    const idx = lines.findIndex((l) => l.startsWith(`${name}=`));
    const line = `${name}=${value}`;
    if (idx >= 0) lines[idx] = line;
    else lines.push(line);
  }
  fs.writeFileSync(ENV_FILE, lines.join('\n') + '\n', 'utf8');
}

function saveSecrets(platformKey, secrets) {
  if (Object.keys(secrets).length === 0) return null;

  const varName = `${platformKey.toUpperCase()}_EXTRA_HEADERS`;
  const lines = readEnvFile().filter((l) => l.trim());
  const index = lines.findIndex((l) => l.startsWith(`${varName}=`));

  let merged = { ...secrets };
  if (index >= 0) {
    try {
      const old = JSON.parse(lines[index].slice(varName.length + 1).replace(/^'|'$/g, ''));
      merged = { ...old, ...secrets };
    } catch {
      // overwrite unreadable line
    }
  }

  const line = `${varName}='${JSON.stringify(merged)}'`;
  if (index >= 0) lines[index] = line;
  else lines.push(line);

  fs.writeFileSync(ENV_FILE, lines.join('\n') + '\n', 'utf8');
  return { varName, value: JSON.stringify(merged) };
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  const platformKey = (args._[0] || '').toLowerCase();
  const raw = new Set(JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8')).platforms ? Object.keys(JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8')).platforms) : []);

  if (!platformKey || !raw.has(platformKey)) {
    console.error(`Usage: platform:import -- <${[...raw].join('|')}> "<curl command>" --name <label> [--pages N] [--page-param p --page-step n --page-in query|body]`);
    process.exit(1);
  }

  const curl = args.file ? fs.readFileSync(args.file, 'utf8') : args._.slice(1).join(' ');
  if (!curl.trim()) {
    console.error('No cURL command given (pass it in quotes, or use --file curl.txt).');
    process.exit(1);
  }

  const parsed = parseCurl(curl);
  if (!/^https?:\/\//i.test(parsed.url)) {
    console.error('Could not find a URL in that cURL command.');
    process.exit(1);
  }

  const publicHeaders = {};
  const secretHeaders = {};
  const location = {};

  for (const [name, value] of Object.entries(parsed.headers)) {
    if (DROP_HEADERS.has(name) || name.startsWith('sec-') || name.startsWith(':')) continue;

    const locVar = locationVar(name);
    if (locVar) {
      // delivery location is personal: keep it out of the committed config
      location[locVar] = value;
      publicHeaders[name] = `{${locVar}}`;
    } else if (SENSITIVE_HEADER_RE.test(name)) {
      secretHeaders[name] = value;
    } else {
      publicHeaders[name] = value;
    }
  }

  const config = JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
  const platform = config.platforms[platformKey];

  // location inside the URL query string
  const urlObj = new URL(parsed.url);
  for (const [qName, qValue] of [...urlObj.searchParams.entries()]) {
    const locVar = locationVar(qName);
    if (locVar) {
      location[locVar] = qValue;
      urlObj.searchParams.set(qName, `{${locVar}}`);
    }
  }
  parsed.url = urlObj.toString().replace(/%7B(\w+)%7D/g, '{$1}');

  // location inside a JSON body
  if (parsed.body !== undefined) {
    try {
      parsed.body = JSON.stringify(replaceInJson(JSON.parse(parsed.body), location));
    } catch {
      // not JSON: leave as is
    }
  }

  const request = {
    name: args.name || `Request ${(platform.requests || []).length + 1}`,
    method: parsed.method,
    url: parsed.url,
    headers: publicHeaders
  };
  if (parsed.body !== undefined) request.body = parsed.body;
  if (args.pages) request.pages = Number(args.pages);
  if (args['page-param']) {
    request.pageParam = args['page-param'];
    request.pageStep = Number(args['page-step']) || 1;
    request.pageStart = Number(args['page-start']) || 0;
    request.pageIn = args['page-in'] || 'query';
  }

  platform.requests = (platform.requests || []).filter((r) => r.name !== request.name);
  platform.requests.push(request);
  platform.enabled = true;

  fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2) + '\n', 'utf8');
  const saved = saveSecrets(platformKey, secretHeaders);

  const locationEnv = {};
  for (const [variable, value] of Object.entries(location)) {
    locationEnv[`${platformKey.toUpperCase()}_${variable === 'storeId' ? 'STORE_ID' : variable.toUpperCase()}`] = value;
  }
  saveEnvVars(locationEnv);

  console.log(`✅ Added request "${request.name}" to ${platformKey} (${parsed.method} ${urlObj.host}${urlObj.pathname}) and enabled the platform.`);
  if (saved) {
    console.log(`🔐 Saved ${Object.keys(secretHeaders).length} secret header(s) to platforms.local.env (git-ignored): ${Object.keys(secretHeaders).join(', ')}`);
    console.log(`   For GitHub Actions add a repository secret named ${saved.varName} with this value:\n   ${saved.value}`);
  }
  if (Object.keys(locationEnv).length) {
    console.log(`📍 Delivery location kept OUT of git: stored as ${Object.keys(locationEnv).join(', ')} in platforms.local.env (add them as GitHub secrets too).`);
  }
  console.log(`\nNext: npm run probe -- ${platformKey}   (verifies the request works and prices parse correctly)`);
}

if (require.main === module) main();

module.exports = { tokenize, parseCurl };
