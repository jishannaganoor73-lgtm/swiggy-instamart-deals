// Usage: npm run telegram:check
// Sends a real test message to every configured Telegram destination and
// prints Telegram's exact error without exposing the bot token.
require('dotenv').config();
const TelegramBot = require('node-telegram-bot-api');
const { verifyTelegram, describeError } = require('./notifier');

(async () => {
  const token = (process.env.TELEGRAM_BOT_TOKEN || '').trim();
  const normalChat = (process.env.TELEGRAM_CHAT_ID || '').trim();

  if (!token || token === 'your_bot_token_here') {
    console.error('❌ TELEGRAM_BOT_TOKEN is missing/placeholder.');
    process.exit(1);
  }
  if (!normalChat) {
    console.error('❌ TELEGRAM_CHAT_ID is missing/empty.');
    process.exit(1);
  }

  const bot = new TelegramBot(token, { polling: false });
  const destinations = [...new Set([
    normalChat,
    (process.env.PRIORITY_CHAT_ID || '').trim(),
    (process.env.HEALTH_CHAT_ID || '').trim()
  ].filter(Boolean))];

  try {
    const preflight = await verifyTelegram(bot, destinations);
    if (!preflight.ok) {
      preflight.problems.forEach((problem) => console.error('❌', problem));
      process.exitCode = 1;
      return;
    }

    let failures = 0;
    for (const chatId of destinations) {
      try {
        await bot.sendMessage(
          chatId,
          '✅ Swiggy Deal Hunter test: Telegram delivery is working.',
          { disable_web_page_preview: true }
        );
        console.log(`✅ Test message delivered to configured chat ${chatId}.`);
      } catch (error) {
        failures++;
        console.error(`❌ Test message failed for chat ${chatId}: ${describeError(error)}`);
      }
    }

    if (failures) {
      console.error(`❌ Telegram test failed for ${failures} destination(s).`);
      process.exitCode = 1;
    } else {
      console.log('✅ All configured Telegram destinations passed.');
    }
  } catch (error) {
    console.error('❌ Telegram diagnostic crashed:', describeError(error));
    process.exitCode = 1;
  } finally {
    if (typeof bot.stopPolling === 'function') {
      try { await bot.stopPolling(); } catch {}
    }
  }
})();
